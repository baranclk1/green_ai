# green_ai_espci
Green AI ESPCI course materials
